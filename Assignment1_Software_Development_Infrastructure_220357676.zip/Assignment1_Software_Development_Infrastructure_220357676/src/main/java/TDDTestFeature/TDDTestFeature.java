/*
 * 
 * 
 * 
 */
package TDDTestFeature;

//import java.util.Scanner;
//import org.junit.jupiter.api.Disabled;
//import org.junit.jupiter.api.Test;


/**
 *
 * @220357676_JesseHiebner_2021
 */
public class TDDTestFeature 
{
    
    //Test Object Equality
     public Object ObjectEquality()
     {
        Object a = 5; 
        Object b = 7;
        boolean Equal;
         if (a.equals(b)) 
         {
         Equal = true;    
         }
         else
         {
             Equal = false;
         }         
        
        return Equal;
    }
    
     //Test Object Identity
    public Object ObjectIdentity()
    {
        Object a = 5; 
        Object b = 7;
        
        
         if (a == b) 
         {
         return "They are Identical";
         }
         else
         {
             return "Unidentical Objects";
         }           
        
    }
    
    //Object FailingTest
    public Object FailingTest()
    {
        try
        {
           Object a = 5;
            Object b = 50;
            System.out.println(a.equals(b));
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    /*
     //Timeout Test
    public ObjectTimeouts()
    {
        // Make MyObject
        
        MyObject Obj = new MyObject(3000);
        // Wait 4 seconds
        wait(4000);
        // 'delete' it, the object made with `new MyObject(4000)` cannot be used anymore.
        O = null;
        return null;
        
        //dont know how to do a timeout test. come back to this
    }
    
    //Disable Test
     */
    
 /*      
public Object DisablingTests() 
{
    @Disabled("Disabled until bug #99 has been fixed");
    @Test
    void testWillBeSkipped() 
 {
    }
//dont know how to test
}
        return null;
    }
   */ 
    public static void Main()
       {
                
       }
}
